import dynamicImport from 'vite-plugin-dynamic-import'

export default {
  plugins: [dynamicImport()],
}
